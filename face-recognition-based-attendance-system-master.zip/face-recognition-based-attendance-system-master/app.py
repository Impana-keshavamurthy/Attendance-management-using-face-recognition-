import cv2
import os
from flask import Flask, request, render_template
from datetime import date, datetime
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
import pandas as pd
import joblib
import logging

# Set up logging
logging.basicConfig(level=logging.DEBUG)

# Defining Flask App
app = Flask(__name__)

nimgs = 10

# Saving Date today in 2 different formats
datetoday = date.today().strftime("%m_%d_%y")
datetoday2 = date.today().strftime("%d-%B-%Y")

# Initializing VideoCapture object to access WebCam
face_detector = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
eye_detector = cv2.CascadeClassifier('haarcascade_eye.xml')

# If these directories don't exist, create them
if not os.path.isdir('Attendance'):
    os.makedirs('Attendance')
if not os.path.isdir('static'):
    os.makedirs('static')
if not os.path.isdir('static/faces'):
    os.makedirs('static/faces')
if f'Attendance-{datetoday}.csv' not in os.listdir('Attendance'):
    with open(f'Attendance/Attendance-{datetoday}.csv', 'w') as f:
        f.write('Name,Roll,Time\n')

# Get the number of total registered users
def totalreg():
    return len(os.listdir('static/faces'))

# Function to extract faces from image
def extract_faces(img):
    try:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        face_points = face_detector.detectMultiScale(gray, 1.2, 5, minSize=(50, 50))  # Adjusted minSize for better accuracy
        return face_points
    except Exception as e:
        app.logger.error(f"Error in extracting faces: {e}")
        return []

# Identify face using ML model
def identify_face(facearray):
    try:
        model = joblib.load('static/face_recognition_model.pkl')
        return model.predict(facearray)
    except Exception as e:
        logging.error(f"Error loading model: {e}")
        return ["Unknown"]

# Function to train the model on all the faces available in the faces folder
def train_model():
    try:
        faces = []
        labels = []
        userlist = os.listdir('static/faces')
        for user in userlist:
            for imgname in os.listdir(f'static/faces/{user}'):
                img = cv2.imread(f'static/faces/{user}/{imgname}')
                resized_face = cv2.resize(img, (50, 50))
                faces.append(resized_face.ravel())
                labels.append(user)
        faces = np.array(faces)
        knn = KNeighborsClassifier(n_neighbors=5)
        knn.fit(faces, labels)
        joblib.dump(knn, 'static/face_recognition_model.pkl')
    except Exception as e:
        app.logger.error(f"Error training model: {e}")

# Extract info from today's attendance file in attendance folder
def extract_attendance():
    df = pd.read_csv(f'Attendance/Attendance-{datetoday}.csv')
    names = df['Name']
    rolls = df['Roll']
    times = df['Time']
    l = len(df)
    return names, rolls, times, l

# Add attendance of a specific user
def add_attendance(name):
    username = name.split('_')[0]
    userid = name.split('_')[1]
    current_time = datetime.now().strftime("%H:%M:%S")

    df = pd.read_csv(f'Attendance/Attendance-{datetoday}.csv')
    if userid in df['Roll'].astype(str).values:
        df.loc[df['Roll'].astype(str) == userid, 'Time'] = current_time
        df.to_csv(f'Attendance/Attendance-{datetoday}.csv', index=False)
    else:
        with open(f'Attendance/Attendance-{datetoday}.csv', 'a') as f:
            f.write(f'{username},{userid},{current_time}\n')

# A function to get names and roll numbers of all users
def getallusers():
    try:
        userlist = os.listdir('static/faces')
        names = []
        rolls = []
        for user in userlist:
            name, roll = user.split('_')
            names.append(name)
            rolls.append(roll)
        l = len(userlist)
        return userlist, names, rolls, l
    except Exception as e:
        app.logger.error(f"Error getting all users: {e}")
        return [], [], [], 0

# A function to delete a user folder
def deletefolder(duser):
    pics = os.listdir(duser)
    for i in pics:
        os.remove(duser+'/'+i)
    os.rmdir(duser)

################## ROUTING FUNCTIONS #########################

# Our main page
@app.route('/')
def home():
    try:
        names, rolls, times, l = extract_attendance()
        return render_template('home.html', names=names, rolls=rolls, times=times, l=l, totalreg=totalreg(), datetoday2=datetoday2)
    except Exception as e:
        logging.error(f"Error in home route: {e}")
        return "An error occurred"

# List users page
@app.route('/listusers')
def listusers():
    try:
        userlist, names, rolls, l = getallusers()
        return render_template('listusers.html', userlist=userlist, names=names, rolls=rolls, l=l, totalreg=totalreg(), datetoday2=datetoday2)
    except Exception as e:
        logging.error(f"Error in listusers route: {e}")
        return "An error occurred"

# Delete functionality
@app.route('/deleteuser', methods=['GET'])
def deleteuser():
    try:
        duser = request.args.get('user')
        deletefolder('static/faces/'+duser)

        # If all the faces are deleted, delete the trained file
        if os.listdir('static/faces/') == []:
            os.remove('static/face_recognition_model.pkl')

        train_model()

        userlist, names, rolls, l = getallusers()
        return render_template('listusers.html', userlist=userlist, names=names, rolls=rolls, l=l, totalreg=totalreg(), datetoday2=datetoday2)
    except Exception as e:
        logging.error(f"Error in deleteuser route: {e}")
        return "An error occurred"

# Modify your start route to use this function
@app.route('/start')
def start():
    try:
        cap = cv2.VideoCapture(0)
        last_detected_person = None
        
        while True:
            ret, frame = cap.read()
            if not ret:
                continue
            
            faces = extract_faces(frame)
            for (x, y, w, h) in faces:
                face = cv2.resize(frame[y:y + h, x:x + w], (50, 50)).ravel().reshape(1, -1)
                identified_person = identify_face(face)[0]
                last_detected_person = identified_person  # Update the last detected person
                cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
                cv2.putText(frame, identified_person, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)
            
            cv2.imshow('Attendance System', frame)
            key = cv2.waitKey(1)
            
            # ESC key to break the loop and stop taking attendance
            if key == 27:
                break
        
        cap.release()
        cv2.destroyAllWindows()
        
        # Update attendance for the last detected person
        if last_detected_person is not None:
            add_attendance(last_detected_person)
        
        # Update attendance after stopping the loop
        names, rolls, times, l = extract_attendance()
        return render_template('home.html', names=names, rolls=rolls, times=times, l=l, mess='Attendance Successful', totalreg=len(os.listdir('static/faces')))
    
    except Exception as e:
        app.logger.error(f"Error in start route: {e}")
        return "An error occurred"

# This function will run when we add a new user.
@app.route('/add', methods=['GET', 'POST'])
def add():
    try:
        if request.method == 'POST':
            newusername = request.form.get('newusername', '')
            newuserid = request.form.get('newuserid', '')
            userimagefolder = f'static/faces/{newusername}_{newuserid}'

            if not os.path.isdir(userimagefolder):
                os.makedirs(userimagefolder)

            i = 0
            cap = cv2.VideoCapture(0)
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)  # Set capture width to 1280
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)  # Set capture height to 720

            while i < nimgs:
                ret, frame = cap.read()
                if not ret:
                    break

                faces = extract_faces(frame)
                for (x, y, w, h) in faces:
                    cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 20), 2)
                    cv2.putText(frame, f'Images Captured: {i+1}/{nimgs}', (30, 30),
                                cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 20), 2, cv2.LINE_AA)

                    # Save face region
                    face_region = frame[y:y + h, x:x + w]
                    cv2.imwrite(os.path.join(userimagefolder, f'{newusername}_{i}_face.jpg'), face_region)

                    # Detect eyes in the face region
                    eyes = eye_detector.detectMultiScale(face_region, scaleFactor=1.1, minNeighbors=3, minSize=(20, 20))
                    eye_boxes = []
                    padding = 10  # Amount of padding to add around the eyes

                    for (ex, ey, ew, eh) in eyes:
                        if ey < h / 2:  # Ensure the detected region is in the upper half of the face
                            eye_boxes.append((x + ex, y + ey, ew, eh))

                    # Draw a single rectangle encompassing both eyes if two eyes are detected
                    if len(eye_boxes) == 2:
                        ex1, ey1, ew1, eh1 = eye_boxes[0]
                        ex2, ey2, ew2, eh2 = eye_boxes[1]
                        ex_min = min(ex1, ex2) - padding
                        ey_min = min(ey1, ey2) - padding
                        ew_max = max(ex1 + ew1, ex2 + ew2) - ex_min + padding * 2
                        eh_max = max(ey1 + eh1, ey2 + eh2) - ey_min + padding * 2

                        # Ensure the rectangle stays within image bounds
                        ex_min = max(0, ex_min)
                        ey_min = max(0, ey_min)
                        ew_max = min(frame.shape[1] - ex_min, ew_max)
                        eh_max = min(frame.shape[0] - ey_min, eh_max)

                        cv2.rectangle(frame, (ex_min, ey_min), (ex_min + ew_max, ey_min + eh_max), (0, 255, 0), 2)
                        eye_region = frame[ey_min:ey_min + eh_max, ex_min:ex_min + ew_max]
                        cv2.imwrite(os.path.join(userimagefolder, f'{newusername}_{i}_eyes.jpg'), eye_region)

                    cv2.imshow('Adding new User', frame)

                    # Wait for spacebar press to capture image
                    key = cv2.waitKey(1)
                    if key == 32:  # 32 is the ASCII code for spacebar
                        i += 1

                if cv2.waitKey(1) == 27:
                    break

            cap.release()
            cv2.destroyAllWindows()

            logging.info('Training Model')
            train_model()

            names, rolls, times, l = extract_attendance()
            return render_template('home.html', names=names, rolls=rolls, times=times, l=l, totalreg=totalreg(), datetoday2=datetoday2)

        elif request.method == 'GET':
            return render_template('add_user.html')  # Adjust the template name as per your setup

    except Exception as e:
        logging.error(f"Error in add route: {e}")
        return "An error occurred"

    return "An error occurred"

# Our main function which runs the Flask App
if __name__ == '__main__':
    app.run(debug=True)


